import random
import time
import tkinter as tk
from tkinter import messagebox
from selenium import webdriver
from selenium.webdriver.edge.service import Service
from selenium.webdriver.common.keys import Keys

presets = [
    "skibidi", "gyatt", "rizz", "only in ohio", "duke dennis", "did you pray today", 
    "livvy dunne", "rizzing up", "baby gronk", "sussy imposter", "pibby", "glitch in real life", 
    "sigma alpha omega male", "grindset", "andrew tate", "goon cave", "freddy fazbear", 
    "colleen ballinger", "smurf cat vs strawberry", "elephant blud dawg", "shmlawg", "ishowspeed", 
    "a whole bunch of turbulence", "ambatukam", "bro really thinks he's carti", "literally hitting the griddy", 
    "the ocky way", "kai cenat", "fanum tax", "garten of banban", "no edging in class", 
    "not the mosquito again", "bussing axel in harlem", "whopper whopper whopper whopper", 
    "1 2 buckle my shoe", "goofy ahh", "aiden ross", "sin city monday left me broken", 
    "quirked up white boy", "busting it down sexual style", "goated with the sauce", 
    "john pork", "grimace shake", "kiki do you love me", "huggy wuggy", "nathaniel b", 
    "lightskin stare", "biggest bird omar the referee", "amogus", "uncanny wholesome", 
    "reddit chungus", "keanu reeves", "pizza tower", "zesty poggers", "kumalala savesta", 
    "quandale dingle", "glizzy rose toy", "ankha zone thug shaker", "morbin time", 
    "dj khaled", "sisyphus", "oceangate shadow wizard", "money gang", "ayo the pizza here", 
    "PLUH nair butthole waxing", "t-pose ugandan knuckles", "family guy funny moments compilation with subway surfers gameplay", 
    "at the bottom nickeh30 ratio uwu", "delulu opium bird cg5", "mewing fortnite battle pass", 
    "all my fellas gta 6 backrooms", "gigachad based cringe kino redpilled", "no nut november pokénut", 
    "november foot fetish F in the chat", "i love lean looksmaxxing gassy", "social credit bing chilling", 
    "xbox live mrbeast kid named finger", "better caul saul i am a surgeon", "hit or miss i guess they never miss huh", 
    "i like ya cut g ice spice gooning", "fr we go gym kevin james", "josh hutcherson coffin of andy and leyley metal pipe falling",
    "python programming", "artificial intelligence", "machine learning", "data science", "blockchain", 
    "cryptocurrency", "robotics", "virtual reality", "augmented reality", "internet of things", 
    "cloud computing", "cybersecurity", "bioinformatics", "nanotechnology", "quantum computing", 
    "genetic engineering", "neuromorphic computing", "space exploration", "fusion energy"
]

def get_unique_random_search_term(used_terms):
    while True:
        term = random.choice(presets)
        if term not in used_terms:
            used_terms.add(term)
            return term

def perform_search(driver, search_term, index):
    try:
        search_box = driver.find_element("name", "q")
        search_box.clear()
        search_box.send_keys(f"{index}. {search_term}")
        search_box.send_keys(Keys.RETURN)
        time.sleep(2)
    except Exception as e:
        print(f"Error: {e}")

def show_popup():
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("Search Completed", "Searching completed.")
    root.destroy()

def main():
    edge_driver_path = r'C:\Users\Mathe\Downloads\msedgedriver.exe'  # Replace <YourUsername> with your actual username
    service = Service(edge_driver_path)
    driver = webdriver.Edge(service=service)

    try:
        driver.get("https://www.bing.com/news?q=")
        used_terms = set()

        for i in range(1, 101):
            search_term = get_unique_random_search_term(used_terms)
            print(f"Searching for: {i}. {search_term}")
            perform_search(driver, search_term, i)
            time.sleep(0.5)

        print("Done")
        time.sleep(5) 

        show_popup()

    finally:
        driver.quit()

if __name__ == "__main__":
    main()





#__  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
#|  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
#| |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
#| |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
#|_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 