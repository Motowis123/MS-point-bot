 Searches things on bing for you so you can get free points.
 This is a phyton scrip you will need to intall pip and selenium. 
 You can preform tasks while it runs in the background, when its done there is a popup click ok and it closes.
 Requires Python, install python here: https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe   #Paste in browser.
 Type this in your cmd to make the script work theese are python ad-ons.
 python get-pip.py                     # Do this one first if you dont allready got pip*
 pip install selenium for


 IMPORTANT!!!
 INSTALL THE EDGE DRIVERS BY USING THE LINK UNDER AND UNZIP IT TO DOAWNLOADS, OPEN THE FILE AND PUT msedgedriver.exe IN YOUR DOWNLOADS BY         DRAGGING IT IN THERE THEN CHECK THE SCRIPT AND FIND THE PLACE WHERE YOU GOT TO CHANGE YOUR USERNAME.
 Paste in browser: https://msedgedriver.azureedge.net/126.0.2592.61/edgedriver_win64.zip
 !! May be outdated if it is, download the stable channel version.
 Link to site: https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/?form=MA13LH          # Paste in browser


 __  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
 |  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
 | |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
 | |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
 |_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 